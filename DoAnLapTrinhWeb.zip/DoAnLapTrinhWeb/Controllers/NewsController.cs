﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DoAnLapTrinhWeb.Models;

namespace DoAnLapTrinhWeb.Controllers
{
    public class NewsController : Controller
    {
        //
        // GET: /News/
        public ActionResult Index()
        {
            QLWebSiteNews_NewEntities db = new QLWebSiteNews_NewEntities();
            List<TinTuc> tt = db.TinTuc.ToList();
            return View(tt);
        }
	}
}